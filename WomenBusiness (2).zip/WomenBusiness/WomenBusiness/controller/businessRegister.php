<?php
include_once '../model/business.php';

$name = filter_var($_POST['name']);
$email = filter_var($_POST['email']);
$phone = filter_var($_POST['phone']);
$category = filter_var($_POST['category']);
$description = filter_var($_POST['description']);

$business = new business();

if(!$business->checkByEmail($email)){

        $business->setRegisterDetails($name,$email,$phone,$category,$description);

        if ($business->create()) {

            $result = ["status" => 'success'];

            echo json_encode($result);


        } else {

            $result = ["status" => 'fail'];

            echo json_encode($result);

        }
    }
    else{

        $result = ["status" => 'fail'];

        echo json_encode($result);

    }
    
    ?>