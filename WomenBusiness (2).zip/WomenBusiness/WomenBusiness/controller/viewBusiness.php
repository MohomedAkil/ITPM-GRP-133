<?php
include_once '../model/business.php';

$email = filter_var($_POST['email']);

$business = new business();

    $result = $business->getterAllByEmail($email);

        if(filter_var($_POST['code'])=="0"){

    if($result){

        $result["status"] = 'success';
        echo json_encode($result);
    }
    else{

        $result = ["status" => 'fail'];
        echo json_encode($result);

    }
}


    if(filter_var($_POST['code'])=="1"){

        $name = filter_var($_POST['name']);
        $email = filter_var($_POST['email']);
        $phone = filter_var($_POST['phone']);
        $category = filter_var($_POST['category']);
        $description = filter_var($_POST['description']);

        $business = new business();

        

                

                if ($business->updateBusiness($name,$email,$phone,$category,$description)) {

                    $result = ["status" => 'success'];

                    echo json_encode($result);


                } else {

                    $result = ["status" => 'fail'];

                    echo json_encode($result);

                }
            }


        if(filter_var($_POST['code'])=="2"){

    
            $email = filter_var($_POST['email']);
            
            $business = new business();

            

                    if ($business->deleteBusiness($email)) {

                        $result = ["status" => 'success'];

                        echo json_encode($result);


                    } else {

                        $result = ["status" => 'fail'];

                        echo json_encode($result);

                    }
        }


?>