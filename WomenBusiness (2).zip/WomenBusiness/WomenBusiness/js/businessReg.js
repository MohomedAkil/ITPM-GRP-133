
$(document).ready(function () {
  //Create slider

  $("#submitForm").click(function (event) {
    event.preventDefault();
    
    if (!$("#name").val() || $("#name").val().length === 0) {

      alert("Please enter business name");

    } else if (!$("#email").val() || $("#email").val().length === 0) {

      alert("Please enter email");

    } else if (!$("#phone").val() || $("#phone").val().length === 0) {

      alert("Please enter phone number");

    } else if (!$("#description").val() || $("#description").val().length === 0) {

      alert("Please enter description");

    } 
    else if (!$("#list option:selected").text()) {

      alert("Please select category");

    } else {
      var name = $("#name").val();
      var email = $("#email").val();
      var phone = $("#phone").val();
      var description = $("#description").val();
      var e = document.getElementById("list");
      var category = e.options[e.selectedIndex].text;

      console.log(name,email,phone,description,category);

      $.ajax({
        type: "POST",
        url: "controller/businessRegister.php",
        data: {
          code: "0",
          name: name,
          email: email,
          phone: phone,
          description: description,
          category: category,
        },
        dataType: "json",
        //if received a response from the server
        success: function (result) {
          if (result.status == "fail") {
            alert("Error while registering");
          } else if (result.status == "success") {
            alert("Success");
            window.location.replace("businesses.php");
          }
        },
      });
    }
  });

   $("#clear").click(function (event) {
     event.preventDefault();

     $("#name").val("");
     $("#email").val("");
     $("#description").val("");
     $("#phone").val("");
     $("#list option:selected").prop("selected", false);
     
   });
});
