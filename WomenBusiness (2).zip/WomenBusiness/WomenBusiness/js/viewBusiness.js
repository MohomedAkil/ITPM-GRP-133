function searchBusiness() {
  document.getElementById("businessDetails").style.visibility = "hidden";

  if (!document.getElementById("searchEmail").value) {
    alert("Please enter email !!");
  } else {
    var email = document.getElementById("searchEmail").value;

    $.ajax({
      type: "POST",
      url: "controller/viewBusiness.php",
      data: {
        email: email,
        code: "0",
      },
      dataType: "json",
      //if received a response from the server
      success: function (result) {
        if (result.status == "fail") {
          alert("No business registration for entered email");
        } else {
          document.getElementById("businessDetails").style.visibility =
            "visible";
          document.getElementById("name").value = result.name;
          document.getElementById("email").value = result.email;
          document.getElementById("phone").value = result.phone;
          document.getElementById("description").value = result.description;

          var selId = document.getElementById("list");

          if (result.category == "Clothing") {
            selId.options[1].selected = true;
          } else if (result.category == "Food and Catering") {
            selId.options[2].selected = true;
          } else if (result.category == "Gardening") {
            selId.options[3].selected = true;
          } else if (result.category == "Home Services") {
            selId.options[4].selected = true;
          } else if (result.category == "Beauty and personal care") {
            selId.options[5].selected = true;
          } else if (result.category == "Fashion and accessories") {
            selId.options[6].selected = true;
          } else if (result.category == "Event planning and coordination") {
            selId.options[7].selected = true;
          } else {
            selId.options[0].selected = true;
          }

          console.log(result);
        }
      },
    });
  }
}

function deleteBusiness() {
  var email = document.getElementById("email").value;

  

  $.ajax({
    type: "POST",
    url: "controller/viewBusiness.php",
    data: {
      code: "2",
      email: email,
    },
    dataType: "json",
    //if received a response from the server
    success: function (result) {
      if (result.status == "fail") {
        alert("Error while deleting");
      } else if (result.status == "success") {
        alert("Deleted");
        window.location.reload("viewBusiness.php")
      }
    },
  });
}

$(document).ready(function () {
  //Create slider

  $("#update").click(function (event) {
    event.preventDefault();

    if (!$("#name").val() || $("#name").val().length === 0) {
      alert("Please enter business name");
    } else if (!$("#email").val() || $("#email").val().length === 0) {
      alert("Please enter email");
    } else if (!$("#phone").val() || $("#phone").val().length === 0) {
      alert("Please enter phone number");
    } else if (
      !$("#description").val() ||
      $("#description").val().length === 0
    ) {
      alert("Please enter description");
    } else if (!$("#list option:selected").text()) {
      alert("Please select category");
    } else if ($("#list option:selected").text() == "Choose category") {
      alert("Please select category");
    } else {
      var name = $("#name").val();
      var email = $("#email").val();
      var phone = $("#phone").val();
      var description = $("#description").val();
      var e = document.getElementById("list");
      var category = e.options[e.selectedIndex].text;

      console.log(name, email, phone, description, category);

      $.ajax({
        type: "POST",
        url: "controller/viewBusiness.php",
        data: {
          code: "1",
          name: name,
          email: email,
          phone: phone,
          description: description,
          category: category,
        },
        dataType: "json",
        //if received a response from the server
        success: function (result) {
          if (result.status == "fail") {
            alert("Error while updating");
          } else if (result.status == "success") {
            alert("Success");
          }
        },
      });
    }
  });

  $("#clear").click(function (event) {
    event.preventDefault();

    $("#name").val("");
    $("#email").val("");
    $("#description").val("");
    $("#phone").val("");
    $("#list option:selected").prop("selected", false);
  });
});
