<?php

include_once 'DBConnection.php';

class business extends DBconnection {

    private $name;
    private $email;
    private $phone;
    private $category;
    private $description;
    private $createdAt;


    public function __construct() {
        parent::__construct();
    }

    public function create() {

         if(($this->checkByEmail($this->email)==FALSE)){
        
            date_default_timezone_set('Asia/Colombo');
            $createdAt = date('Y-m-d H:i:s');
            $sql = "INSERT INTO `business` (name,email,phone,category,description,createdAt)  VALUES  ('" .$this->name. "', '" .$this->email. "','" .$this->phone. "','" .$this->category. "', '" .$this->description. "', '" .$this->createdAt. "')";

            if (mysqli_query($this->connection, $sql)) {

                return TRUE;
            } else {
                return FALSE;
            }
        }
        else{
            return FALSE;
        }
    }

    public function setRegisterDetails($name,$email,$phone,$category,$description){

        $this->name = $name;
       
        $this->email = $email;
        $this->phone = $phone;
        $this->category = $category;
        $this->description = $description;
    }

    public function checkByEmail($email) {

        if ($email) {

            $sql = "SELECT id FROM business WHERE email = '$email'";

            $query = mysqli_query($this->connection, $sql);
            $result = $query->fetch_assoc();

            if(mysqli_num_rows($query) > 0){
                return TRUE;
            }
            else{
                return FALSE;
            }

        }

    }

    public function getterAllByEmail($email) {

        if ($email) {

            $sql = "SELECT * FROM `business` WHERE `email`= '$email'";

            $query = mysqli_query($this->connection, $sql);

            $result = $query->fetch_assoc();

            if($result){

                $this->id = $result['id'];
                $this->name = $result['name'];
                $this->email = $result['email'];
                $this->phone = $result['phone'];
                $this->category = $result['category'];
                $this->description = $result['description'];
                $this->createdAt = $result['createdAt'];
                $this->setBusinessSession($result);
            }
            
            return $result;
        }
    }

    public function updateBusiness($name,$email,$phone,$category,$description){

        $sql = "UPDATE `business` SET `name` ='" . $name . "', `phone` = '" . $phone . "', `category` = '" . $category . "', `description` = '" . $description . "' WHERE `email`='" . $email . "'";

        $result = mysqli_query($this->connection, $sql);

        if ($result) {

            return TRUE;
        } else {

            return FALSE;
        }

    }

    public function deleteBusiness($email){

        $sql = 'DELETE FROM `business` WHERE email="' . $email . '"';

        return $query = mysqli_query($this->connection, $sql);
    }

    public function getBusinessById() {

            $sql = "SELECT * FROM `business`";

            $query = mysqli_query($this->connection, $sql);

            $array_res = array();
            while ($row = $query->fetch_assoc()) {

                array_push($array_res, $row);
            }
            return $array_res;

    }

    private function setBusinessSession($business) {



        if (!isset($_SESSION)) {

            session_start();
        }

        $_SESSION["id"] = $business['id'];
        $_SESSION["name"] = $business['name'];
        $_SESSION["email"] = $business['email'];
        $_SESSION["phone"] = $business['phone'];
        $_SESSION["category"] = $business['category'];
        $_SESSION["description"] = $business['description'];
        $_SESSION["createdAt"] = $business['createdAt'];
    }
}