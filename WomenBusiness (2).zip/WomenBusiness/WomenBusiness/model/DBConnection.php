<?php

class DBconnection {

//    // main conection
    private $serverName = "localhost";
    private $userName = "root";
    private $password = "";
    private $databaseName = "itpm";

    
    protected $connection;

    protected function __construct() {

        $this->connection = new mysqli($this->serverName, $this->userName, $this->password, $this->databaseName);


        if (!$this->connection) {
            echo 'Cannot connect to database server';
        } else {
            return $this->connection;
        }
    }

}

?>