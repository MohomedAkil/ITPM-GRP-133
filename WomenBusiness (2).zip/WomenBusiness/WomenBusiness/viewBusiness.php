
<!DOCTYPE html>

<?php
include_once './model/business.php';

$business =new business();

?>
<html>



<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <title>Businesses</title>
    
        <style>
            body{
            font-family: 'Open Sans';
            }
        </style>
        
        <link
        href="css/viewBusiness.css"
        rel="stylesheet"
        />

        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>

        <!-- Font Awesome -->
        <link
        href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css"
        rel="stylesheet"
        />
        <!-- Google Fonts -->
        <link
        href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700&display=swap"
        rel="stylesheet"
        />
        <!-- MDB -->
        <link
        href="https://cdnjs.cloudflare.com/ajax/libs/mdb-ui-kit/6.2.0/mdb.min.css"
        rel="stylesheet"
        />

        <!-- MDB -->
        <script
        type="text/javascript"
        src="https://cdnjs.cloudflare.com/ajax/libs/mdb-ui-kit/6.2.0/mdb.min.js"
        ></script>

        <!-- Custom js -->
        <script type="text/javascript" src="js/viewBusiness.js"></script>

       
        

</head>
<body>

<div>

<nav class="navbar navbar-expand-lg bg-primary">
  <div class="container-fluid">
    
    <div class="collapse navbar-collapse" id="navbarNav">
      <ul class="navbar-nav">
        <li class="nav-item">
          <a class="nav-link active" aria-current="page" href="businesses.php">Home</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="viewBusiness.php">View Business</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="businessReg.php">New Business</a>
        </li>
        
      </ul>
    </div>
  </div>
</nav>

    <h1 id="page_title">Search Business Details</h1>


    <div class="input-group container" id="search_group">
        <div class="form-outline">
            <input id="searchEmail" type="text" class="form-control" placeholder="Search by email" />
        </div>
        <button type="button" onclick="searchBusiness()" style="background-color:#327dff; border-radius:10px; width:80px; border:none;" ><i class="fas fa-search"></i></button>
    </div>

    <div class="container" id="businessDetails">

        <div class="container" id="reg_form">



            <lable>Business Name</lable>
                <input class="form-control mr-2" type="text" placeholder="Name" aria-label="Search" id="name">

            <lable>Email</lable><span style="color:red; font-size:10px;"> *cannot change</span>
                <input class="form-control mr-2" type="text" placeholder="Email" aria-label="Search" id="email" readonly>
                    
            <lable>Phone No</lable>        
                <input class="form-control mr-2" type="text" placeholder="Phone no" aria-label="Search" id="phone">

            <!-- <lable>Category</lable>        
            <input class="form-control mr-2" type="text" placeholder="Phone no" aria-label="Search" id="category"> -->

            <lable>Category</lable>
        <select class="form-select form-select-lg mb-3" aria-label=".form-select-lg example" id="list">

                <option>Choose category</option>
                <option >Clothing</option>
                <option>Food and Catering</option>
                <option>Gardening</option>
                <option>Home Services</option>
                <option>Beauty and personal care</option>
                <option>Fashion and accessories</option>
                <option>Event planning and coordination</option>

        </select>

            <lable>Description</lable>
                <textarea class="form-control" aria-label="With textarea" id="description"></textarea>


                <button type="button" style=" border-radius:10px; width:150px; border:none; margin-left:100px;margin-top:50px;" ><a href="business-report.php">Genarate Report</a></button>


            </div>

            <div id="button_group">
                
                <button type="button" class="btn btn-outline-success" data-mdb-ripple-color="dark" id="delete" onClick="deleteBusiness()">Delete</button>
            
                <button type="button" class="btn btn-outline-info" data-mdb-ripple-color="dark" style="margin-left:100px;" id="update">Update</button>
                
            </div>
            
    </div>


    

</div>

<div class="card text-center">
  <div class="card-header">
    Women Businesses
  </div>
  <div class="card-body">
    <h5 class="card-title">Special title treatment</h5>
    <p class="card-text">With supporting text below as a natural lead-in to additional content.</p>
    <a href="businesses.php" class="btn btn-primary">Home</a>
  </div>
  <div class="card-footer text-body-secondary">
    2 days ago
  </div>
</div>
</body>

</html>