<?php
session_start();
require_once 'FPDF/fpdf184/fpdf.php';
include_once './model/business.php';

        // $Business = new business();
        // $bookings =  $Business->getBusinessById();
            
        date_default_timezone_set('Asia/Colombo');
        $createdAt = date('Y-m-d');


//customer and business details
  $info=[
    "id"=>$_SESSION['id'],
    "name"=>$_SESSION['name'],
    "email"=>$_SESSION['email'],
    "phone"=>$_SESSION['phone'],
    "category"=>$_SESSION['category'],
    "description"=>$_SESSION['description'],
    "createdAt"=>$_SESSION['createdAt'],
  ];
  
  
  class PDF extends FPDF
  {
    function Header(){
      
      //Display Company Info
      $this->SetFont('Arial','B',14);
      $this->Cell(50,10,"Women business",0,1);
      $this->SetFont('Arial','',14);
      $this->Cell(50,7,"West Street,",0,1);
      $this->Cell(50,7,"Salem 636002.",0,1);
      $this->Cell(50,7,"PH : 8778731770",0,1);
      
      //Display INVOICE text
      $this->SetY(15);
      $this->SetX(-80);
      $this->SetFont('Arial','B',18);
      $this->Cell(50,10,"Business Summary",0,1);
      
      //Display Horizontal line
      $this->Line(0,48,210,48);
    }
    
    function body(){
      
      //Billing Details
      $this->SetY(55);
      $this->SetX(10);
      $this->SetFont('Arial','B',12);
      $this->Cell(50,10,"Customer Info: ",0,1);
      $this->SetFont('Arial','',12);
      $this->Cell(50,7,$_SESSION['name'],0,1);
      $this->Cell(50,7,$_SESSION['email'],0,1);
      $this->Cell(50,7,$_SESSION['category'],0,1);
      
      //Display Invoice no
      // $this->SetY(55);
      // $this->SetX(-60);
      // $this->Cell(50,7,"Id : "$_SESSION["id"]);
      
      // //Display Invoice date
      // $this->SetY(63);
      // $this->SetX(-60);
      // $this->Cell(50,7,"Date : "+$createdAt);
      
      //Display Table headings
      $this->SetY(95);
      $this->SetX(10);
      $this->SetFont('Arial','B',12);
      $this->Cell(20,9,"Id",1,0);
      $this->Cell(40,9,"Name",1,0);
      $this->Cell(60,9,"Email",1,0,"C");
      $this->Cell(30,9,"Phone",1,0,"C");
      $this->Cell(40,9,"category",1,1,"C");
      $this->SetFont('Arial','',12);
      
      //Display table product rows
    
        $this->Cell(20,9,$_SESSION["id"],"LR",0);
        $this->Cell(40,9,$_SESSION["name"],"LR",0);
        $this->Cell(60,9,$_SESSION["email"],"R",0,"R");
        $this->Cell(30,9,$_SESSION["phone"],"R",0,"C");
        $this->Cell(40,9,$_SESSION["category"],"R",1,"R");
      

      //Display table empty rows

        $this->Cell(20,9,"","LR",0);
        $this->Cell(40,9,"","LR",0);
        $this->Cell(60,9,"","R",0,"R");
        $this->Cell(30,9,"","R",0,"C");
        $this->Cell(40,9,"","R",1,"R");


        $this->SetFont('Arial','B',12);
        $this->Cell(150,9,"",1,0,"R");
        $this->Cell(40,9,"",1,0,"R");
      
    
      
    }
    function Footer(){
      
      //set footer position
      $this->Ln(15);
      $this->SetFont('Arial','',12);
      $this->Cell(0,10,"Authorized Signature",0,1,"R");
      $this->SetFont('Arial','',10);
      
      //Display Footer Text
      $this->Cell(0,10,"This is a computer generated invoice",0,1,"C");
      
    }
    
  }
  //Create A4 Page with Portrait 
  $pdf=new PDF("P","mm","A4");
  $pdf->AddPage();
  $pdf->body();
  $pdf->Output();

?>
